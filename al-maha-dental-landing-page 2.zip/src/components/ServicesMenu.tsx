import React, { useState } from 'react';
import { SERVICES } from '../data/clinicData';
import { Calendar, Clock, Sparkles, CheckCircle2 } from 'lucide-react';

interface ServicesMenuProps {
  onOpenBooking: (service?: string) => void;
}

export const ServicesMenu: React.FC<ServicesMenuProps> = ({ onOpenBooking }) => {
  const [filter, setFilter] = useState<'all' | 'cosmetic' | 'therapeutic' | 'general'>('all');

  const filteredServices = filter === 'all'
    ? SERVICES
    : SERVICES.filter((s) => s.category === filter);

  return (
    <section id="services" className="py-20 bg-slate-50 border-y border-slate-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-block bg-blue-100 text-[#1A6B9A] font-bold text-sm px-4 py-1.5 rounded-full">
            قائمة الخدمات التخصصية
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            خدماتنا المتخصصة
          </h2>
          <p className="text-slate-600 text-lg leading-relaxed">
            نقدم حلولاً متكاملة للعناية بأسنانك تحت سقف واحد، باستخدام أحدث الأجهزة والمواد المعتمدة عالمياً.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-16">
          {[
            { id: 'all', label: 'جميع الخدمات' },
            { id: 'cosmetic', label: 'تجميل الأسنان' },
            { id: 'therapeutic', label: 'علاجي وجراحي' },
            { id: 'general', label: 'رعاية عامة وأطفال' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`px-6 py-3 rounded-2xl font-bold text-sm sm:text-base transition-all flex items-center gap-2 ${
                filter === tab.id
                  ? 'bg-[#1A6B9A] text-white shadow-lg shadow-[#1A6B9A]/25 scale-105'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200/80 shadow-sm'
              }`}
            >
              <Sparkles className={`w-4 h-4 ${filter === tab.id ? 'text-[#C9A84C]' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-3xl overflow-hidden border border-slate-200/80 shadow-md hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Image & Overlay */}
                <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent" />
                  
                  {/* Duration Tag */}
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md text-slate-800 text-xs font-bold px-3 py-1.5 rounded-xl shadow-sm flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#1A6B9A]" />
                    <span>{service.duration}</span>
                  </div>

                  {/* Title overlay */}
                  <div className="absolute bottom-4 inset-x-4 text-white text-right">
                    <h3 className="text-xl font-extrabold mb-1 group-hover:text-[#C9A84C] transition-colors">
                      {service.title}
                    </h3>
                    <p className="text-xs text-slate-200 font-medium line-clamp-1">
                      {service.subtitle}
                    </p>
                  </div>
                </div>

                {/* Content Body */}
                <div className="p-6 space-y-4">
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {service.description}
                  </p>

                  {/* Features list */}
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    {service.features.map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => onOpenBooking(service.title)}
                  className="w-full bg-slate-100 hover:bg-[#1A6B9A] text-slate-800 hover:text-white py-3 rounded-xl font-bold text-sm shadow-sm hover:shadow-lg hover:shadow-[#1A6B9A]/20 transition-all flex items-center justify-center gap-2 group/btn"
                >
                  <Calendar className="w-4 h-4 text-[#1A6B9A] group-hover/btn:text-[#C9A84C] transition-colors" />
                  <span>احجز موعد لهذه الخدمة</span>
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
