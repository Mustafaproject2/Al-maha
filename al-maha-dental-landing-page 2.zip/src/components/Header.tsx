import React, { useState } from 'react';
import { Phone, Calendar, Menu, X, ShieldCheck, Sparkles } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

interface HeaderProps {
  onOpenBooking: (service?: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenBooking }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'الرئيسية', href: '#hero' },
    { name: 'لماذا نحن', href: '#features' },
    { name: 'خدماتنا', href: '#services' },
    { name: 'آراء المرضى', href: '#testimonials' },
    { name: 'الأسئلة الشائعة', href: '#faqs' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-100">
      {/* Top Bar */}
      <div className="bg-[#1A6B9A] text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-1.5 font-medium">
            <ShieldCheck className="w-4 h-4 text-[#C9A84C]" />
            <span>{CLINIC_INFO.accreditation} (ترخيص رقم {CLINIC_INFO.licenseNumber})</span>
          </div>
          <div className="flex items-center gap-4 hidden sm:flex">
            <span>📍 {CLINIC_INFO.location}</span>
            <span>⏰ {CLINIC_INFO.workingHours}</span>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Logo */}
          <a href="#hero" className="flex items-center gap-3.5 group">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#1A6B9A] to-[#135277] flex items-center justify-center text-white shadow-md shadow-[#1A6B9A]/20 group-hover:scale-105 transition-transform">
              <Sparkles className="w-6 h-6 text-[#C9A84C]" />
            </div>
            <div>
              <div className="font-extrabold text-xl text-[#1A6B9A] tracking-tight flex items-center gap-1">
                {CLINIC_INFO.name}
              </div>
              <div className="text-xs text-slate-500 font-medium tracking-wide">طب أسنان تخصصي متقدم</div>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-slate-600 hover:text-[#1A6B9A] font-semibold text-base transition-colors py-2 relative after:absolute after:bottom-0 after:right-0 after:w-0 after:h-0.5 after:bg-[#C9A84C] hover:after:w-full after:transition-all"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* CTA & Phone Buttons */}
          <div className="hidden lg:flex items-center gap-4">
            <a
              href={`tel:${CLINIC_INFO.phone}`}
              className="flex items-center gap-2 text-[#1A6B9A] bg-blue-50/80 hover:bg-blue-100/80 px-4 py-2.5 rounded-xl font-bold transition-all border border-blue-100"
            >
              <Phone className="w-5 h-5 text-[#1A6B9A]" />
              <span className="text-sm" dir="ltr">{CLINIC_INFO.phoneDisplay}</span>
            </a>

            <button
              onClick={() => onOpenBooking()}
              className="flex items-center gap-2 bg-[#C9A84C] hover:bg-[#b5953e] text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-[#C9A84C]/25 hover:shadow-xl hover:shadow-[#C9A84C]/40 hover:-translate-y-0.5 transition-all text-base"
            >
              <Calendar className="w-5 h-5" />
              <span>احجز موعدك المجاني</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-3 md:hidden">
            <button
              onClick={() => onOpenBooking()}
              className="bg-[#C9A84C] text-white p-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md"
            >
              <Calendar className="w-4 h-4" />
              <span>احجز الآن</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-slate-100 text-slate-600 hover:text-slate-900"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 py-6 space-y-4 animate-fade-in">
          <nav className="flex flex-col gap-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-slate-700 hover:text-[#1A6B9A] font-bold text-lg py-2 border-b border-slate-100"
              >
                {link.name}
              </a>
            ))}
          </nav>

          <div className="pt-4 flex flex-col gap-3">
            <a
              href={`tel:${CLINIC_INFO.phone}`}
              className="flex items-center justify-center gap-2 text-[#1A6B9A] bg-blue-50 py-3 rounded-xl font-bold border border-blue-100"
            >
              <Phone className="w-5 h-5" />
              <span>اتصل بنا: <span dir="ltr">{CLINIC_INFO.phoneDisplay}</span></span>
            </a>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="w-full flex items-center justify-center gap-2 bg-[#C9A84C] text-white py-3.5 rounded-xl font-bold text-base shadow-lg shadow-[#C9A84C]/20"
            >
              <Calendar className="w-5 h-5" />
              <span>احجز موعدك المجاني الآن</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
