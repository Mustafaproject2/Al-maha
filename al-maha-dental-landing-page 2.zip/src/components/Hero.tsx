import React from 'react';
import { Calendar, ShieldCheck, Star, CheckCircle, ArrowLeft } from 'lucide-react';

interface HeroProps {
  onOpenBooking: (service?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section id="hero" className="relative overflow-hidden bg-gradient-to-b from-blue-50/50 via-white to-white py-12 lg:py-20">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 -mt-20 -mr-20 w-96 h-96 rounded-full bg-blue-100/50 blur-3xl -z-10 pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-96 h-96 rounded-full bg-amber-100/40 blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Content Column */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-right">
            
            {/* Accreditation Tag */}
            <div className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm border border-slate-100 text-[#1A6B9A] text-sm font-bold animate-fade-in">
              <ShieldCheck className="w-5 h-5 text-[#C9A84C]" />
              <span>رعاية طبية معتمدة وفق أعلى معايير الجودة</span>
            </div>

            {/* Main Headings */}
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.2]">
                ابتسامتك تستحق الأفضل
              </h1>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#1A6B9A] leading-normal">
                عيادة ابتسامة المها — حيث تبدأ ثقتك بنفسك
              </h2>
            </div>

            {/* Subtitle / Intro Text */}
            <div className="text-slate-600 text-lg sm:text-xl font-normal leading-relaxed max-w-2xl mx-auto lg:mx-0 space-y-3 border-r-4 border-[#C9A84C] pr-4 py-1 bg-gradient-to-l from-amber-50/30 to-transparent">
              <p>
                نقدّم لك رعاية أسنان استثنائية بأيدي نخبة من الاستشاريين المعتمدين، باستخدام أحدث التقنيات الطبية في قلب الرياض.
              </p>
              <p className="font-semibold text-slate-700">
                لأن ابتسامتك ليست تفصيلاً صغيراً — إنها أول ما يراه العالم منك.
              </p>
            </div>

            {/* Main CTA */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <button
                onClick={() => onOpenBooking()}
                className="w-full sm:w-auto bg-[#C9A84C] hover:bg-[#b5953e] text-white text-lg font-bold px-8 py-5 rounded-2xl shadow-xl shadow-[#C9A84C]/30 hover:shadow-2xl hover:shadow-[#C9A84C]/40 hover:-translate-y-1 transition-all flex items-center justify-center gap-3 group"
              >
                <Calendar className="w-6 h-6 animate-bounce" />
                <span>احجز موعدك المجاني الآن</span>
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              </button>

              <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="flex -space-x-2 -space-x-reverse">
                  <span className="w-8 h-8 rounded-full bg-blue-100 border-2 border-white flex items-center justify-center text-xs font-bold text-[#1A6B9A]">+8k</span>
                  <span className="w-8 h-8 rounded-full bg-amber-100 border-2 border-white flex items-center justify-center text-xs font-bold text-[#C9A84C]">★</span>
                  <span className="w-8 h-8 rounded-full bg-emerald-100 border-2 border-white flex items-center justify-center text-xs font-bold text-emerald-600">✓</span>
                </div>
                <div className="text-xs text-slate-600 font-semibold text-right">
                  <div>يثق بنا أكثر من ٨٬٠٠٠ مريض</div>
                  <div className="text-amber-500 flex items-center gap-0.5">
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <span className="text-slate-500 mr-1">(٤٫٩)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bullet points */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 max-w-xl mx-auto lg:mx-0">
              {[
                "استشارة أولية مجانية",
                "أطباء استشاريون معتمدون",
                "خطط تقسيط ميسرة 0%",
                "أحدث تقنيات 3D CBCT",
                "تعقيم فائق المعايير",
                "مواعيد دقيقة بدون انتظار"
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                  <CheckCircle className="w-4 h-4 text-[#1A6B9A] flex-shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>

          </div>

          {/* Image & Floating Badges Column */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto w-full max-w-md lg:max-w-none">
              
              {/* Main Image Frame */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-slate-100 aspect-[4/5] z-10">
                <img
                  src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1000&q=80"
                  alt="طاقم طبي وعيادة ابتسامة المها"
                  className="w-full h-full object-cover object-center hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent" />
                
                {/* Overlay Text */}
                <div className="absolute bottom-6 inset-x-6 text-white text-right">
                  <div className="bg-white/20 backdrop-blur-md p-4 rounded-2xl border border-white/30">
                    <div className="font-bold text-lg mb-1">دقة التشخيص وجمال النتيجة</div>
                    <p className="text-xs text-slate-100 leading-relaxed">نجمع بين المهارة الطبية الفائقة واللمسة التجميلية لنمنحك الابتسامة التي تحلم بها.</p>
                  </div>
                </div>
              </div>

              {/* Floating Badge 1: Satisfaction */}
              <div className="absolute -top-6 -right-6 bg-white p-4 rounded-2xl shadow-xl border border-slate-100 z-20 flex items-center gap-3 animate-fade-in">
                <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center text-2xl shadow-inner">
                  🏆
                </div>
                <div>
                  <div className="font-extrabold text-xl text-slate-900">٩٨٪</div>
                  <div className="text-xs text-slate-500 font-bold">نسبة رضا المرضى</div>
                </div>
              </div>

              {/* Floating Badge 2: Experience */}
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-2xl shadow-xl border border-slate-100 z-20 flex items-center gap-3 animate-fade-in">
                <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-2xl shadow-inner text-[#1A6B9A]">
                  🩺
                </div>
                <div>
                  <div className="font-extrabold text-xl text-slate-900">+١٥ عاماً</div>
                  <div className="text-xs text-slate-500 font-bold">خبرة استشارية</div>
                </div>
              </div>

              {/* Decorative dots */}
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-radial from-[#1A6B9A]/20 to-transparent blur-md -z-10" />

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
