import React, { useState } from 'react';
import { TESTIMONIALS, Testimonial } from '../data/clinicData';
import { Star, Quote, MessageSquarePlus, CheckCircle } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const [reviews, setReviews] = useState<Testimonial[]>(TESTIMONIALS);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newRole, setNewRole] = useState('');
  const [newQuote, setNewQuote] = useState('');
  const [newService, setNewService] = useState('عام');
  const [successMsg, setSuccessMsg] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor || !newQuote) return;

    const newTestimonial: Testimonial = {
      id: `custom-${Date.now()}`,
      rating: 5,
      quote: newQuote,
      author: newAuthor,
      role: newRole || 'زائر كريم، الرياض',
      service: newService,
      avatarBg: 'bg-blue-100 text-[#1A6B9A]'
    };

    setReviews([newTestimonial, ...reviews]);
    setNewAuthor('');
    setNewRole('');
    setNewQuote('');
    setSuccessMsg(true);
    setShowAddForm(false);

    setTimeout(() => {
      setSuccessMsg(false);
    }, 4000);
  };

  return (
    <section id="testimonials" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-block bg-amber-50 text-[#C9A84C] font-bold text-sm px-4 py-1.5 rounded-full border border-amber-200/60">
            تجارب ملهمة
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            ماذا يقول مرضانا؟
          </h2>
          <h4 className="text-[#1A6B9A] text-lg sm:text-xl font-bold">
            آراء حقيقية من أشخاص غيّرنا ابتسامتهم
          </h4>
          <p className="text-slate-600 text-base leading-relaxed max-w-2xl mx-auto">
            قصص نجاح تعكس التزامنا بتقديم رعاية طبية لا تضاهى. تعرف على تجارب زوارنا مع مختلف التخصصات.
          </p>
        </div>

        {/* Success message toast */}
        {successMsg && (
          <div className="max-w-md mx-auto mb-8 bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl flex items-center gap-3 animate-fade-in shadow-lg">
            <CheckCircle className="w-6 h-6 text-emerald-600 flex-shrink-0" />
            <div className="text-sm font-bold">شكراً لك! تم إضافة تقييمك بنجاح وسيظهر في القائمة أدناه.</div>
          </div>
        )}

        {/* Interactive Add Review Button */}
        <div className="flex justify-center mb-12">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-6 py-3 rounded-2xl flex items-center gap-2 transition-all border border-slate-200 shadow-sm"
          >
            <MessageSquarePlus className="w-5 h-5 text-[#1A6B9A]" />
            <span>{showAddForm ? 'إلغاء إضافة رأي' : 'شاركنا تجربتك في العيادة'}</span>
          </button>
        </div>

        {/* Add Review Form Modal / Drawer */}
        {showAddForm && (
          <form onSubmit={handleSubmit} className="max-w-xl mx-auto bg-slate-50 p-8 rounded-3xl border border-slate-200 shadow-xl mb-16 animate-fade-in space-y-6">
            <h3 className="text-xl font-bold text-slate-900 text-center">إضافة تقييم جديد</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">الاسم الكريم *</label>
                <input
                  type="text"
                  required
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="مثال: خالد العتيبي"
                  className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-800 focus:outline-none focus:border-[#1A6B9A] shadow-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">المهنة والمدينة</label>
                <input
                  type="text"
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value)}
                  placeholder="مثال: معلم، الرياض"
                  className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-800 focus:outline-none focus:border-[#1A6B9A] shadow-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">الخدمة المتلقاة</label>
                <select
                  value={newService}
                  onChange={(e) => setNewService(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-800 focus:outline-none focus:border-[#1A6B9A] shadow-sm"
                >
                  <option value="التقويم الشفاف (Invisalign)">التقويم الشفاف (Invisalign)</option>
                  <option value="زراعة الأسنان (إمبلنت)">زراعة الأسنان (إمبلنت)</option>
                  <option value="تصميم الابتسامة الرقمي">تصميم الابتسامة الرقمي</option>
                  <option value="تبييض الأسنان المتقدم">تبييض الأسنان المتقدم</option>
                  <option value="علاج جذور الأسنان">علاج جذور الأسنان</option>
                  <option value="تنظيف الأسنان وصحة اللثة">تنظيف الأسنان وصحة اللثة</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">نص التقييم والتجربة *</label>
                <textarea
                  required
                  rows={3}
                  value={newQuote}
                  onChange={(e) => setNewQuote(e.target.value)}
                  placeholder="تحدث عن تجربتك مع أطباء العيادة ومستوى العناية..."
                  className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-800 focus:outline-none focus:border-[#1A6B9A] shadow-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#1A6B9A] hover:bg-[#135277] text-white py-3.5 rounded-xl font-bold text-base shadow-md transition-all"
            >
              نشر التقييم
            </button>
          </form>
        )}

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {reviews.map((t) => (
            <div
              key={t.id}
              className="bg-slate-50 hover:bg-white rounded-3xl p-8 border border-slate-100 hover:border-[#1A6B9A]/30 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Top Row: Stars & Quote Icon */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1 text-amber-500">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                  <Quote className="w-8 h-8 text-slate-200 group-hover:text-[#C9A84C] transition-colors" />
                </div>

                {/* Quote Text */}
                <p className="text-slate-700 text-base sm:text-lg leading-relaxed italic mb-8">
                  "{t.quote}"
                </p>
              </div>

              {/* Author & Service Info */}
              <div className="flex items-center gap-4 pt-6 border-t border-slate-200/60">
                <div className={`w-12 h-12 rounded-2xl ${t.avatarBg} flex items-center justify-center font-black text-xl shadow-inner`}>
                  {t.author.charAt(0)}
                </div>
                <div>
                  <div className="font-extrabold text-slate-900 text-base">{t.author}</div>
                  <div className="text-xs text-slate-500 font-medium">{t.role}</div>
                  <div className="text-xs text-[#1A6B9A] font-bold mt-0.5">الخدمة: {t.service}</div>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
