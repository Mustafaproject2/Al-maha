import React from 'react';
import { Calendar, PhoneCall } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

interface StickyMobileCTAProps {
  onOpenBooking: () => void;
}

export const StickyMobileCTA: React.FC<StickyMobileCTAProps> = ({ onOpenBooking }) => {
  return (
    <div className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 p-3 shadow-lg flex items-center gap-2 md:hidden animate-fade-in">
      <button
        onClick={onOpenBooking}
        className="flex-1 bg-[#C9A84C] hover:bg-[#b5953e] text-white py-3 px-4 rounded-xl font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all"
      >
        <Calendar className="w-4 h-4 animate-bounce" />
        <span>احجز موعدك المجاني</span>
      </button>

      <a
        href={`tel:${CLINIC_INFO.phone}`}
        className="bg-[#1A6B9A] hover:bg-[#135277] text-white p-3 rounded-xl flex items-center justify-center shadow-md transition-all"
        aria-label="اتصل بنا"
      >
        <PhoneCall className="w-5 h-5" />
      </a>
    </div>
  );
};
