import React, { useState } from 'react';
import { SERVICES } from '../data/clinicData';
import { X, Calendar, CheckCircle2, PhoneCall, Sparkles, User, Clock } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedService?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, preselectedService }) => {
  const [selectedService, setSelectedService] = useState(preselectedService || SERVICES[0].title);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [prefDate, setPrefDate] = useState('');
  const [prefTime, setPrefTime] = useState('صباحاً (٩:٠٠ص - ١٢:٠٠م)');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [bookingCode, setBookingCode] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    // Generate random booking code
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    setBookingCode(`MAHA-${randomNum}`);
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setName('');
    setPhone('');
    setPrefDate('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 relative">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-6 left-6 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 hover:bg-slate-200 transition-all z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="bg-[#1A6B9A] p-8 text-white text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]" />
          <div className="relative z-10 space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-white/10 mx-auto flex items-center justify-center mb-3 border border-white/20">
              <Sparkles className="w-6 h-6 text-[#C9A84C]" />
            </div>
            <h3 className="text-2xl font-extrabold tracking-tight">حجز استشارة مجانية</h3>
            <p className="text-blue-100 text-xs">احصل على كشف مبدئي وخطة علاجية مخصصة بدون أي تكاليف</p>
          </div>
        </div>

        {/* Modal Body */}
        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="p-8 space-y-6">
            
            <div className="space-y-4">
              {/* Service Selection */}
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">الخدمة المطلوبة</label>
                <select
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-4 py-3 text-slate-800 font-medium focus:outline-none focus:border-[#1A6B9A] shadow-sm"
                >
                  {SERVICES.map((s) => (
                    <option key={s.id} value={s.title}>{s.title}</option>
                  ))}
                </select>
              </div>

              {/* Name Input */}
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">الاسم الكريم *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-5 h-5" />
                  </span>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="أدخل اسمك الكامل"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl pr-10 pl-4 py-3 text-slate-800 font-medium focus:outline-none focus:border-[#1A6B9A] shadow-sm"
                  />
                </div>
              </div>

              {/* Phone Input */}
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">رقم الجوال *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                    <PhoneCall className="w-5 h-5" />
                  </span>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="05XXXXXXXX"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl pr-10 pl-4 py-3 text-slate-800 font-medium focus:outline-none focus:border-[#1A6B9A] shadow-sm text-right"
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">سيتواصل معك موظف الاستقبال لتأكيد الموعد</p>
              </div>

              {/* Date & Time Preferences */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">التاريخ المفضل</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                      <Calendar className="w-5 h-5" />
                    </span>
                    <input
                      type="date"
                      value={prefDate}
                      onChange={(e) => setPrefDate(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl pr-10 pl-4 py-3 text-slate-800 font-medium focus:outline-none focus:border-[#1A6B9A] shadow-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">الوقت المفضل</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                      <Clock className="w-5 h-5" />
                    </span>
                    <select
                      value={prefTime}
                      onChange={(e) => setPrefTime(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl pr-10 pl-4 py-3 text-slate-800 font-medium focus:outline-none focus:border-[#1A6B9A] shadow-sm"
                    >
                      <option value="صباحاً (٩:٠٠ص - ١٢:٠٠م)">صباحاً (٩:٠٠ص - ١٢:٠٠م)</option>
                      <option value="ظهراً (١٢:٠٠م - ٤:٠٠م)">ظهراً (١٢:٠٠م - ٤:٠٠م)</option>
                      <option value="مساءً (٤:٠٠م - ١٠:٠٠م)">مساءً (٤:٠٠م - ١٠:٠٠م)</option>
                    </select>
                  </div>
                </div>
              </div>

            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                className="w-full bg-[#C9A84C] hover:bg-[#b5953e] text-white py-4 rounded-xl font-extrabold text-lg shadow-xl shadow-[#C9A84C]/30 hover:shadow-2xl transition-all"
              >
                تأكيد طلب الحجز المجاني
              </button>
            </div>

            <div className="text-center text-xs text-slate-500 font-medium">
              🔒 بياناتك مشفرة ومحمية بالكامل وفق معايير الخصوصية الطبية.
            </div>

          </form>
        ) : (
          /* Success Screen */
          <div className="p-10 text-center space-y-6 animate-fade-in">
            <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center text-3xl shadow-inner">
              <CheckCircle2 className="w-12 h-12" />
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-black text-slate-900">تم تسجيل طلبك بنجاح!</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                أهلاً بك يا <span className="font-bold text-[#1A6B9A]">{name}</span> في عيادة ابتسامة المها. تم استلام طلبك الخاص بخدمة <span className="font-bold text-[#1A6B9A]">{selectedService}</span>.
              </p>
            </div>

            {/* Booking Code Card */}
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 max-w-xs mx-auto space-y-2">
              <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">كود الحجز المبدئي</div>
              <div className="text-2xl font-mono font-black text-[#1A6B9A] tracking-widest">{bookingCode}</div>
              <div className="text-xs text-emerald-600 font-bold pt-1">سيقوم موظف الاستقبال بالاتصال بك قريباً لتأكيد الموعد النهائي.</div>
            </div>

            <div className="pt-4">
              <button
                onClick={handleReset}
                className="w-full bg-[#1A6B9A] hover:bg-[#135277] text-white py-3.5 rounded-xl font-bold text-base shadow-md transition-all"
              >
                إغلاق والعودة للموقع
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
