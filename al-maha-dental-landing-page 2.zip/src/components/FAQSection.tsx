import React, { useState } from 'react';
import { FAQS } from '../data/clinicData';
import { ChevronDown, HelpCircle, PhoneCall } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

export const FAQSection: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>(FAQS[0].id);

  const toggleFaq = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <section id="faqs" className="py-20 bg-white relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center space-y-4 mb-16">
          <div className="inline-block bg-blue-50 text-[#1A6B9A] font-bold text-sm px-4 py-1.5 rounded-full">
            إجابات وافية لراحتك
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            الأسئلة الشائعة
          </h2>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto">
            جمعنا لك الإجابات عن أكثر الاستفسارات التي تهم زوار عيادة ابتسامة المها.
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-4">
          {FAQS.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                className={`border rounded-2xl transition-all duration-300 overflow-hidden ${
                  isOpen ? 'bg-slate-50 border-blue-200 shadow-md' : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <button
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full p-6 text-right flex items-center justify-between gap-4 focus:outline-none"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className={`w-6 h-6 flex-shrink-0 transition-colors ${isOpen ? 'text-[#1A6B9A]' : 'text-slate-400'}`} />
                    <span className="font-extrabold text-base sm:text-lg text-slate-900">{faq.question}</span>
                  </div>
                  <ChevronDown className={`w-5 h-5 text-slate-500 transition-transform duration-300 flex-shrink-0 ${isOpen ? 'transform rotate-180 text-[#1A6B9A]' : ''}`} />
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-0 text-slate-600 text-sm sm:text-base leading-relaxed animate-fade-in border-t border-slate-100/80 pt-4">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still Have Questions Box */}
        <div className="mt-12 bg-gradient-to-r from-blue-50 via-amber-50/30 to-blue-50 p-8 rounded-3xl border border-blue-100 text-center space-y-4">
          <h3 className="text-xl font-bold text-slate-900">لديك استفسار آخر لم تجد إجابته؟</h3>
          <p className="text-slate-600 text-sm max-w-lg mx-auto">فريق خدمة العملاء والاستقبال متاح للرد على كافة أسئلتك وحجز موعد استشارتك المبدئية بكل سرور.</p>
          <div className="pt-2">
            <a
              href={`tel:${CLINIC_INFO.phone}`}
              className="inline-flex items-center gap-2 bg-[#1A6B9A] hover:bg-[#135277] text-white px-8 py-3.5 rounded-xl font-bold shadow-md transition-all"
            >
              <PhoneCall className="w-5 h-5 text-[#C9A84C]" />
              <span>اتصل بنا مباشرة: <span dir="ltr">{CLINIC_INFO.phoneDisplay}</span></span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
