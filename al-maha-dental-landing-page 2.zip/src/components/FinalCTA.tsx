import React from 'react';
import { CLINIC_INFO } from '../data/clinicData';
import { Calendar, PhoneCall, MapPin, Clock, Sparkles } from 'lucide-react';

interface FinalCTAProps {
  onOpenBooking: (service?: string) => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onOpenBooking }) => {
  return (
    <section className="py-20 bg-gradient-to-b from-slate-50 to-white relative overflow-hidden">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Outer Premium Frame */}
        <div className="relative rounded-3xl bg-gradient-to-r from-[#1A6B9A] via-[#135277] to-[#1A6B9A] p-1 sm:p-2 shadow-2xl overflow-hidden">
          
          {/* Subtle gold decorative border */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#C9A84C]/40 via-transparent to-[#C9A84C]/40 pointer-events-none" />

          {/* Inner Content Box */}
          <div className="relative rounded-[22px] bg-[#1A6B9A] bg-opacity-95 px-6 py-12 sm:p-16 text-center text-white space-y-10 backdrop-blur-sm border border-white/10">
            
            {/* Top Icon */}
            <div className="w-16 h-16 rounded-2xl bg-white/10 mx-auto flex items-center justify-center border border-white/20 shadow-inner">
              <Sparkles className="w-8 h-8 text-[#C9A84C]" />
            </div>

            {/* Main Invitation Text */}
            <div className="space-y-4 max-w-2xl mx-auto">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-normal">
                ابتسامتك تستحق أن تُرى بوضوح
              </h2>
              <p className="text-xl sm:text-2xl text-blue-100 font-bold leading-relaxed">
                احجز استشارتك المجانية اليوم
                <br className="hidden sm:block" /> وخطوتك الأولى نحو الابتسامة التي تريدها
              </p>
            </div>

            {/* Big Action Button */}
            <div>
              <button
                onClick={() => onOpenBooking()}
                className="bg-[#C9A84C] hover:bg-[#b5953e] text-white text-xl font-extrabold px-10 py-6 rounded-2xl shadow-xl shadow-black/20 hover:shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-3 mx-auto group border border-amber-300/40"
              >
                <Calendar className="w-7 h-7 animate-bounce" />
                <span>احجز موعدك الآن — مجاناً</span>
              </button>
            </div>

            {/* Bottom Contact Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-10 border-t border-white/15 max-w-3xl mx-auto text-right sm:text-center">
              
              <div className="flex items-center sm:flex-col justify-start sm:justify-center gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
                <PhoneCall className="w-6 h-6 text-[#C9A84C] flex-shrink-0" />
                <div>
                  <div className="text-xs text-blue-200 font-medium">هاتف الحجز المباشر</div>
                  <div className="font-bold text-lg" dir="ltr">{CLINIC_INFO.phoneDisplay}</div>
                </div>
              </div>

              <div className="flex items-center sm:flex-col justify-start sm:justify-center gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
                <MapPin className="w-6 h-6 text-[#C9A84C] flex-shrink-0" />
                <div>
                  <div className="text-xs text-blue-200 font-medium">موقع العيادة</div>
                  <div className="font-bold text-sm sm:text-base">{CLINIC_INFO.location}</div>
                </div>
              </div>

              <div className="flex items-center sm:flex-col justify-start sm:justify-center gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
                <Clock className="w-6 h-6 text-[#C9A84C] flex-shrink-0" />
                <div>
                  <div className="text-xs text-blue-200 font-medium">ساعات العمل</div>
                  <div className="font-bold text-xs sm:text-sm">{CLINIC_INFO.workingHours}</div>
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
