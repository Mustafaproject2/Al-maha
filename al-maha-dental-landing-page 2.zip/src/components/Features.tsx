import React from 'react';
import { FEATURES } from '../data/clinicData';

export const Features: React.FC = () => {
  return (
    <section id="features" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-block bg-blue-50 text-[#1A6B9A] font-bold text-sm px-4 py-1.5 rounded-full">
            معايير التفوق والرعاية
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            لماذا يختار المئات عيادة ابتسامة المها؟
          </h2>
          <p className="text-slate-600 text-lg leading-relaxed">
            نحن لا نعالج الأسنان فحسب، بل نبني علاقة ثقة مستدامة تمزج بين الخبرة الطبية المتقدمة والراحة النفسية التامة.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {FEATURES.map((feature, index) => (
            <div
              key={feature.id}
              className="bg-slate-50 hover:bg-white rounded-3xl p-8 border border-slate-100 hover:border-blue-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group flex flex-col justify-between"
            >
              <div>
                {/* Icon Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-white shadow-md flex items-center justify-center text-3xl group-hover:scale-110 transition-transform duration-300 border border-slate-100 group-hover:border-[#C9A84C]">
                    {feature.icon}
                  </div>
                  <span className="text-5xl font-black text-slate-200/60 group-hover:text-blue-100 transition-colors">
                    0{index + 1}
                  </span>
                </div>

                {/* Title & Description */}
                <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-[#1A6B9A] transition-colors">
                  {feature.title}
                </h3>
                <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {/* Bottom decorative bar */}
              <div className="w-12 h-1 bg-slate-200 group-hover:bg-[#C9A84C] group-hover:w-full transition-all duration-500 rounded-full mt-6" />
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
