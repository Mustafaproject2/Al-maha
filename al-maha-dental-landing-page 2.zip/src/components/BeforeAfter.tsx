import React, { useState } from 'react';
import { BEFORE_AFTER_SMILES } from '../data/clinicData';
import { Calendar, Sparkles, Check } from 'lucide-react';

interface BeforeAfterProps {
  onOpenBooking: (service?: string) => void;
}

export const BeforeAfter: React.FC<BeforeAfterProps> = ({ onOpenBooking }) => {
  const [selectedCase, setSelectedCase] = useState(BEFORE_AFTER_SMILES[0]);
  const [viewMode, setViewMode] = useState<'both' | 'before' | 'after'>('both');

  return (
    <section className="py-20 bg-slate-50 border-y border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-block bg-blue-100 text-[#1A6B9A] font-bold text-sm px-4 py-1.5 rounded-full">
            عدسات رقمية وتقويم متقدم
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            شاهد التحول الفعلي لابتسامات مرضانا
          </h2>
          <p className="text-slate-600 text-lg leading-relaxed">
            نتائج حقيقية وموثقة تعكس التناغم بين صحة اللثة وجمال الأسنان وتناسق ملامح الوجه.
          </p>
        </div>

        {/* Case Selector Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {BEFORE_AFTER_SMILES.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setSelectedCase(item);
                setViewMode('both');
              }}
              className={`px-6 py-3 rounded-2xl font-bold text-base transition-all flex items-center gap-2 shadow-sm ${
                selectedCase.id === item.id
                  ? 'bg-[#1A6B9A] text-white shadow-md shadow-[#1A6B9A]/20 scale-105'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <Sparkles className={`w-5 h-5 ${selectedCase.id === item.id ? 'text-[#C9A84C]' : 'text-slate-400'}`} />
              <span>{item.title}</span>
            </button>
          ))}
        </div>

        {/* Case Viewer */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-slate-100 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Details Column */}
          <div className="lg:col-span-5 space-y-6">
            <div className="inline-block bg-amber-100 text-[#C9A84C] font-bold text-xs px-3 py-1 rounded-lg">
              مدة العلاج: {selectedCase.duration}
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {selectedCase.title}
            </h3>

            <p className="text-slate-600 text-base leading-relaxed">
              {selectedCase.description}
            </p>

            <div className="space-y-3 pt-2 border-t border-slate-100">
              <div className="flex items-center gap-2 text-sm text-slate-700 font-semibold">
                <Check className="w-5 h-5 text-emerald-600" />
                <span>المريض: {selectedCase.patientName}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-700 font-semibold">
                <Check className="w-5 h-5 text-emerald-600" />
                <span>تخطيط رقمي مسبق لمطابقة النتيجة</span>
              </div>
            </div>

            <div className="pt-4">
              <button
                onClick={() => onOpenBooking(selectedCase.title)}
                className="w-full sm:w-auto bg-[#1A6B9A] hover:bg-[#135277] text-white px-8 py-4 rounded-xl font-bold shadow-lg shadow-[#1A6B9A]/20 transition-all flex items-center justify-center gap-2"
              >
                <Calendar className="w-5 h-5" />
                <span>احجز استشارة لهذه الحالة</span>
              </button>
            </div>
          </div>

          {/* Images Comparison Column */}
          <div className="lg:col-span-7 space-y-4">
            
            {/* View Mode Toggles */}
            <div className="flex justify-center gap-2 bg-slate-100 p-1.5 rounded-2xl max-w-xs mx-auto">
              <button
                onClick={() => setViewMode('both')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${viewMode === 'both' ? 'bg-white text-[#1A6B9A] shadow-sm' : 'text-slate-600'}`}
              >
                مقارنة (قبل وبعد)
              </button>
              <button
                onClick={() => setViewMode('before')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${viewMode === 'before' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-600'}`}
              >
                قبل العلاج
              </button>
              <button
                onClick={() => setViewMode('after')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${viewMode === 'after' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-600'}`}
              >
                بعد العلاج
              </button>
            </div>

            {/* Image Frame */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {(viewMode === 'both' || viewMode === 'before') && (
                <div className={`relative rounded-2xl overflow-hidden shadow-md aspect-[4/3] border-2 border-rose-200 ${viewMode === 'before' ? 'sm:col-span-2 aspect-[16/9]' : ''}`}>
                  <img src={selectedCase.beforeImg} alt="قبل العلاج" className="w-full h-full object-cover filter brightness-90" />
                  <div className="absolute top-4 right-4 bg-rose-600 text-white text-xs font-bold px-3 py-1 rounded-lg shadow">
                    قبل العلاج
                  </div>
                </div>
              )}

              {(viewMode === 'both' || viewMode === 'after') && (
                <div className={`relative rounded-2xl overflow-hidden shadow-md aspect-[4/3] border-2 border-emerald-200 ${viewMode === 'after' ? 'sm:col-span-2 aspect-[16/9]' : ''}`}>
                  <img src={selectedCase.afterImg} alt="بعد العلاج" className="w-full h-full object-cover" />
                  <div className="absolute top-4 right-4 bg-emerald-600 text-white text-xs font-bold px-3 py-1 rounded-lg shadow">
                    النتيجة النهائية (بعد)
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
