import React from 'react';
import { CLINIC_INFO } from '../data/clinicData';
import { Sparkles, MessageCircle, Share2, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-16 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Info Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 pb-12 border-b border-slate-800">
          
          {/* Col 1: Brand & About */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1A6B9A] to-[#135277] flex items-center justify-center text-white shadow-md">
                <Sparkles className="w-5 h-5 text-[#C9A84C]" />
              </div>
              <span className="font-extrabold text-xl text-white tracking-tight">{CLINIC_INFO.name}</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
              نقدّم لك رعاية أسنان استثنائية بأيدي نخبة من الاستشاريين المعتمدين، باستخدام أحدث التقنيات الطبية في قلب الرياض.
            </p>
            <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold pt-2">
              <ShieldCheck className="w-4 h-4" />
              <span>{CLINIC_INFO.accreditation}</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-base border-b border-slate-800 pb-2 inline-block">روابط سريعة</h4>
            <ul className="space-y-2 text-sm font-medium">
              <li><a href="#hero" className="hover:text-white transition-colors">الرئيسية</a></li>
              <li><a href="#features" className="hover:text-white transition-colors">لماذا يختارنا المرضى</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">قائمة الخدمات</a></li>
              <li><a href="#testimonials" className="hover:text-white transition-colors">آراء الزوار</a></li>
              <li><a href="#faqs" className="hover:text-white transition-colors">الأسئلة الشائعة</a></li>
            </ul>
          </div>

          {/* Col 3: Social Media Channels */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-base border-b border-slate-800 pb-2 inline-block">حساباتنا الرسمية</h4>
            <div className="flex flex-wrap gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all"
              >
                <span>انستغرام</span>
              </a>
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all"
              >
                <span>تيك توك</span>
              </a>
              <a
                href={`https://wa.me/${CLINIC_INFO.phone}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 px-4 py-2 rounded-xl text-xs font-bold transition-all border border-emerald-700/50"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>واتساب</span>
              </a>
              <a
                href="https://snapchat.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-amber-900/60 hover:bg-amber-800 text-amber-300 px-4 py-2 rounded-xl text-xs font-bold transition-all border border-amber-700/50"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>سناب شات</span>
              </a>
            </div>
          </div>

        </div>

        {/* Bottom Copyright & Legal Links */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div>
            © ٢٠٢٥ عيادة ابتسامة المها — جميع الحقوق محفوظة
          </div>

          <div className="flex items-center gap-6 text-slate-400">
            <a href="#privacy" onClick={(e) => { e.preventDefault(); alert("سياسة الخصوصية: نلتزم بحماية بياناتك وسجلاتك الطبية بسرية تامة وفق أنظمة وزارة الصحة السعودية."); }} className="hover:text-white transition-colors">سياسة الخصوصية</a>
            <a href="#terms" onClick={(e) => { e.preventDefault(); alert("شروط الاستخدام: كافة المعلومات الواردة في الموقع تثقيفية ولا تغني عن الاستشارة الطبية المباشرة في العيادة."); }} className="hover:text-white transition-colors">شروط الاستخدام</a>
            <a href={`tel:${CLINIC_INFO.phone}`} className="hover:text-white transition-colors font-bold text-[#C9A84C]">تواصل معنا</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
