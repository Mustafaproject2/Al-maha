import React from 'react';
import { STATS } from '../data/clinicData';
import { Users, Award, ThumbsUp, Sparkles } from 'lucide-react';

export const Stats: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Users': return <Users className="w-8 h-8 text-[#C9A84C]" />;
      case 'Award': return <Award className="w-8 h-8 text-[#C9A84C]" />;
      case 'ThumbsUp': return <ThumbsUp className="w-8 h-8 text-[#C9A84C]" />;
      case 'Sparkles': return <Sparkles className="w-8 h-8 text-[#C9A84C]" />;
      default: return <Sparkles className="w-8 h-8 text-[#C9A84C]" />;
    }
  };

  return (
    <section className="py-20 bg-gradient-to-r from-[#1A6B9A] via-[#135277] to-[#1A6B9A] text-white relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-block bg-white/10 backdrop-blur-md text-[#C9A84C] font-bold text-sm px-4 py-1.5 rounded-full border border-white/10">
            أرقام تعكس التزامنا
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
            ثقة تبنّاها الآلاف
          </h2>
          <p className="text-blue-100 text-lg leading-relaxed max-w-2xl mx-auto">
            نفخر بكوننا الخيار الأول لآلاف العائلات والأفراد في الرياض، ونعمل يومياً للحفاظ على هذه الثقة الغالية.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {STATS.map((stat) => (
            <div
              key={stat.id}
              className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/10 text-center hover:bg-white/15 transition-all duration-300 group hover:-translate-y-1 shadow-xl shadow-black/10"
            >
              <div className="w-16 h-16 rounded-2xl bg-white/10 mx-auto flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 border border-white/15">
                {getIcon(stat.icon)}
              </div>

              <div className="text-4xl sm:text-5xl font-black text-white mb-2 tracking-tight">
                {stat.number}
              </div>

              <div className="text-lg font-bold text-[#C9A84C] mb-1">
                {stat.label}
              </div>

              {stat.sublabel && (
                <div className="text-xs text-blue-200 font-medium">
                  {stat.sublabel}
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
