import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Stats } from './components/Stats';
import { BeforeAfter } from './components/BeforeAfter';
import { Testimonials } from './components/Testimonials';
import { ServicesMenu } from './components/ServicesMenu';
import { FAQSection } from './components/FAQSection';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { StickyMobileCTA } from './components/StickyMobileCTA';

export const App: React.FC = () => {
  const [bookingOpen, setBookingOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<string | undefined>(undefined);

  const handleOpenBooking = (serviceName?: string) => {
    setSelectedService(serviceName);
    setBookingOpen(true);
  };

  const handleCloseBooking = () => {
    setBookingOpen(false);
    setSelectedService(undefined);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-[#1A6B9A] selection:text-white pb-16 md:pb-0">
      {/* Premium Header */}
      <Header onOpenBooking={handleOpenBooking} />

      {/* Main Content Sections */}
      <main className="flex-grow">
        <Hero onOpenBooking={handleOpenBooking} />
        <Features />
        <Stats />
        <BeforeAfter onOpenBooking={handleOpenBooking} />
        <Testimonials />
        <ServicesMenu onOpenBooking={handleOpenBooking} />
        <FAQSection />
        <FinalCTA onOpenBooking={handleOpenBooking} />
      </main>

      {/* Professional Footer */}
      <Footer />

      {/* Interactive Booking Modal */}
      <BookingModal
        isOpen={bookingOpen}
        onClose={handleCloseBooking}
        preselectedService={selectedService}
      />

      {/* Mobile Sticky CTA */}
      <StickyMobileCTA onOpenBooking={() => handleOpenBooking()} />
    </div>
  );
};

export default App;
